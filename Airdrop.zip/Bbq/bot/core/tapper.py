import asyncio
from time import time
from random import randint
from urllib.parse import unquote, quote, parse_qs
from typing import Optional, Dict
import aiohttp
from aiohttp_proxy import ProxyConnector
from better_proxy import Proxy
from pyrogram import Client
from pyrogram.errors import (
    Unauthorized,
    UserDeactivated,
    AuthKeyUnregistered,
    FloodWait,
)
from pyrogram.raw.functions.messages import RequestWebView
import json
from bot.config import settings
from bot.utils import logger
from bot.exceptions import InvalidSession
from .headers import headers
import base64
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad


class Tapper:
    def __init__(self, tg_client: Client):
        self.session_name = tg_client.name
        self.tg_client = tg_client

    async def randomized_sleep(self, min_seconds=3, max_seconds=6):
        delay = randint(min_seconds * 1000, max_seconds * 1000) / 1000
        logger.info(f"Sleep {delay}s")
        await asyncio.sleep(delay=delay)

    async def get_tg_web_data(self, proxy: Optional[str]) -> str:
        if proxy:
            proxy = Proxy.from_str(proxy)
            proxy_dict = dict(
                scheme=proxy.protocol,
                hostname=proxy.host,
                port=proxy.port,
                username=proxy.login,
                password=proxy.password,
            )
        else:
            proxy_dict = None

        self.tg_client.proxy = proxy_dict

        try:
            with_tg = True

            if not self.tg_client.is_connected:
                with_tg = False
                try:
                    await self.tg_client.connect()
                except (Unauthorized, UserDeactivated, AuthKeyUnregistered):
                    raise InvalidSession(self.session_name)

            while True:
                try:
                    peer = await self.tg_client.resolve_peer("bbqcoin_bot")
                    break
                except FloodWait as fl:
                    fls = fl.value

                    logger.warning(f"{self.session_name} | FloodWait {fl}")
                    logger.info(f"{self.session_name} | Sleeping for {fls} seconds")

                    await asyncio.sleep(fls + 3)

            web_view = await self.tg_client.invoke(
                RequestWebView(
                    peer=peer,
                    bot=peer,
                    platform="android",
                    from_bot_menu=False,
                    url="https://bbqapp.bbqcoin.ai/",
                )
            )

            auth_url = web_view.url
            raw_tg_web_data = unquote(
                unquote(
                    auth_url.split("tgWebAppData=", maxsplit=1)[1].split(
                        "&tgWebAppVersion", maxsplit=1
                    )[0]
                )
            )
            tg_web_data = quote(raw_tg_web_data, safe="=&")

            me = await self.tg_client.get_me()
            self.user_id = me.id
            self.user_name = me.username

            if not with_tg:
                await self.tg_client.disconnect()

            return tg_web_data

        except InvalidSession as error:
            raise error

        except Exception as error:
            logger.error(
                f"{self.session_name} | Unknown error during Authorization: {error}"
            )
            await asyncio.sleep(delay=3)

    async def login(
        self, http_client: aiohttp.ClientSession, tg_web_data: str
    ) -> dict[str, str]:
        try:
            parsed_data = parse_qs(tg_web_data)
            user_data_json = parsed_data.get("user", [""])[0]
            user_data = json.loads(user_data_json)
            payload = {
                "id": user_data.get("id", ""),
                "first_name": user_data.get("first_name", ""),
                "last_name": user_data.get("last_name", ""),
                "username": user_data.get("username", ""),
                "language_code": user_data.get("language_code", ""),
                "allows_write_to_pm": str(
                    user_data.get("allows_write_to_pm", "")
                ).lower(),
            }
            response = await http_client.post(
                url="https://bbqbackcs.bbqcoin.ai/api/user/login", data=payload
            )
            response.raise_for_status()
            response_json = await response.json()
            profile_data = response_json["data"]
            return profile_data
        except Exception as error:
            logger.error(
                f"{self.session_name} | Unknown error while getting user Profile Data: {error}"
            )
            await asyncio.sleep(delay=3)

    async def apply_boost_status(
        self, http_client: aiohttp.ClientSession, boost_type: int
    ) -> bool:
        try:
            payload = {"id_user": self.user_id, "free_task_id": boost_type}
            response = await http_client.post(
                url="https://bbqbackcs.bbqcoin.ai/api/tasks/freetask",
                data=payload,
            )
            response.raise_for_status()
            response_json = await response.json()
            boost_status = response_json["data"]

            return boost_status
        except Exception as error:
            logger.error(
                f"{self.session_name} | Unknown error when checking Boost Status {error}"
            )
            await asyncio.sleep(delay=3)

            return False

    async def apply_boost(
        self, http_client: aiohttp.ClientSession, boost_type: int
    ) -> bool:
        try:
            payload = {"id_user": self.user_id, "free_task_id": boost_type}
            response = await http_client.post(
                url="https://bbqbackcs.bbqcoin.ai/api/tasks/freetask",
                data=payload,
            )
            response.raise_for_status()

            return True
        except Exception as error:
            logger.error(
                f"{self.session_name} | Unknown error when Apply {boost_type} Boost: {error}"
            )
            await asyncio.sleep(delay=3)

            return False

    async def upgrade_boost(
        self, http_client: aiohttp.ClientSession, boost_type: str
    ) -> bool:
        try:
            payload = {"id_user": self.user_id, "type": boost_type}
            response = await http_client.post(
                url="https://bbqbackcs.bbqcoin.ai/api/tasks/upgrade",
                data=payload,
            )
            response.raise_for_status()

            return True
        except Exception as error:
            logger.error(
                f"{self.session_name} | Unknown error when Upgrade {boost_type} Boost: {error}"
            )
            await asyncio.sleep(delay=3)

            return False

    async def claim_reward(
        self, http_client: aiohttp.ClientSession, task_id: str
    ) -> bool:
        try:
            payload = {"id_user": self.user_id, "type": task_id}
            await self.randomized_sleep()
            response = await http_client.post(
                url="https://bbqbackcs.bbqcoin.ai/api/tasks/dotask",
                data=payload,
            )
            response.raise_for_status()

            return True
        except Exception as error:
            logger.error(
                f"{self.session_name} | Unknown error when Claim {task_id} Reward: {error}"
            )
            await asyncio.sleep(delay=3)

            return False

    async def encode_game(self, telegram_id: int, taps: int):
        current_time = int(time())
        combined_string = f"{telegram_id}|{taps}|{current_time}"
        key_string = "tttttttttttttttttttttttttttttttt"
        iv_string = key_string[:16]
        key_bytes = key_string.encode("utf-8")
        iv_bytes = iv_string.encode("utf-8")
        cipher = AES.new(key_bytes, AES.MODE_CBC, iv_bytes)
        encrypted_data = cipher.encrypt(
            pad(combined_string.encode("utf-8"), AES.block_size)
        )
        encoded_data = base64.b64encode(encrypted_data).decode("utf-8")
        final_encoded_data = base64.b64encode(encoded_data.encode("utf-8")).decode(
            "utf-8"
        )
        return final_encoded_data

    async def send_taps(
        self, http_client: aiohttp.ClientSession, taps: int, encoded_data: str
    ) -> dict[str]:
        try:
            payload = {"id_user": self.user_id, "mm": taps, "game": encoded_data}
            response = await http_client.post(
                url="https://bbqbackcs.bbqcoin.ai/api/coin/earnmoney",
                data=payload,
            )
            response.raise_for_status()

            response_json = await response.json()
            player_data = response_json
            return player_data
        except Exception as error:
            logger.error(f"{self.session_name} | Unknown error when Tapping: {error}")
            await asyncio.sleep(delay=3)

    async def check_proxy(
        self, http_client: aiohttp.ClientSession, proxy: Proxy
    ) -> None:
        try:
            response = await http_client.get(
                url="https://httpbin.org/ip", timeout=aiohttp.ClientTimeout(5)
            )
            ip = (await response.json()).get("origin")
            logger.info(f"{self.session_name} | Proxy IP: {ip}")
        except Exception as error:
            logger.error(f"{self.session_name} | Proxy: {proxy} | Error: {error}")

    async def run(self, proxy: str | None) -> None:
        turbo_time = 0
        active_turbo = False

        proxy_conn = ProxyConnector().from_url(proxy) if proxy else None

        async with aiohttp.ClientSession(
            headers=headers.copy(), connector=proxy_conn
        ) as http_client:
            if proxy:
                await self.check_proxy(http_client=http_client, proxy=proxy)

            while True:
                try:
                    tg_web_data = await self.get_tg_web_data(proxy=proxy)
                    http_client.headers.update({"Use-Agen": tg_web_data})
                    profile_data = await self.login(
                        http_client=http_client, tg_web_data=tg_web_data
                    )

                    balance = profile_data["balancusdt"]


                    with open('levels.json', 'r') as levels_file:
                                levels_data =  json.load(levels_file)

                    tap_prices = {
                        index + 1: data["money"]
                        for index, data in enumerate(levels_data["multitap"])
                    }
                    
                    energy_prices = {
                        index + 1: data["money"]
                        for index, data in enumerate(levels_data["buffery"])
                    }
                    
                    charge_prices = {
                        index + 1: data["money"]
                        for index, data in enumerate(levels_data["recover"])
                    }
                    
                    board_tasks = profile_data["task_lib"]["boardTasks"]
                    special_tasks = profile_data["task_lib"]["specialsTasks"]

                    task_ids = {task["tag"] for task in board_tasks.values()} | {task["tag"] for task in special_tasks}

                    # for task_id in task_ids:
                    #     await self.randomized_sleep()
                    #     logger.info(
                    #         f"{self.session_name} | Sleep before claim <m>{task_id}</m> reward"
                    #     )
                    #     status = await self.claim_reward(
                    #         http_client=http_client, task_id=task_id
                    #     )
                    #     if status is True:
                    #         logger.success(
                    #             f"{self.session_name} | Successfully claimed <m>{task_id}</m> reward"
                    #         )
                    #         await asyncio.sleep(delay=1)

                    taps = randint(
                        a=settings.RANDOM_TAPS_COUNT[0], b=settings.RANDOM_TAPS_COUNT[1]
                    )

                    if active_turbo:
                        taps += settings.ADD_TAPS_ON_TURBO
                        if time() - turbo_time > 20:
                            active_turbo = False
                            turbo_time = 0

                    final_encoded_data = await self.encode_game(telegram_id = self.user_id, taps = taps)

                    player_data = await self.send_taps(http_client=http_client, taps=taps, encoded_data = final_encoded_data)
                    if not player_data:
                     logger.warning("Empty or unexpected response from send_taps")
                     continue       

                    available_energy = float('inf')
                    updated_balance = player_data["data"]
                    new_balance = updated_balance
                    calc_taps = abs(new_balance - balance)
                    balance = new_balance
                    total = balance

                    boost_status = await self.apply_boost_status(
                        http_client=http_client, boost_type=0
                    )

                    turbo_boost_count = boost_status["free_double"]
                    energy_boost_count = boost_status["free_recover"]

                    next_tap_level = profile_data["level"] + 1
                    next_energy_level = profile_data["bufferylevel"] + 1
                    next_charge_level = profile_data["recoverlevel"] + 1

                    logger.success(
                        f"{self.session_name} | Successful tapped! | "
                        f"Balance: <c>{balance}</c> (<g>+{calc_taps}</g>) | Total: <e>{total}</e>"
                    )

                    if active_turbo is False:
                        if (
                            energy_boost_count > 0
                            and available_energy < settings.MIN_AVAILABLE_ENERGY
                            and settings.APPLY_DAILY_ENERGY is True
                        ):
                            await self.randomized_sleep()
                            status = await self.apply_boost(
                                http_client=http_client, boost_type=1
                            )
                            if status is True:
                                logger.success(
                                    f"{self.session_name} | Full Energy boost applied"
                                )
                                await asyncio.sleep(delay=1)
                            continue

                        if turbo_boost_count > 0 and settings.APPLY_DAILY_TURBO is True:
                            await self.randomized_sleep()
                            status = await self.apply_boost(
                                http_client=http_client, boost_type=2
                            )
                            if status is True:
                                logger.success(
                                    f"{self.session_name} | Turbo boost applied"
                                )
                                await asyncio.sleep(delay=1)
                                active_turbo = True
                                turbo_time = time()
                            continue

                        if (
                            settings.AUTO_UPGRADE_TAP is True
                            and balance > tap_prices.get(next_tap_level +1, 0)
                            and next_tap_level <= settings.MAX_TAP_LEVEL
                        ):
                            await self.randomized_sleep()
                            status = await self.upgrade_boost(
                                http_client=http_client, boost_type="level"
                            )
                            if status is True:
                                logger.success(
                                    f"{self.session_name} | MultiTap upgraded to {next_tap_level} lvl"
                                )
                                await asyncio.sleep(delay=1)
                            continue

                        if (
                            settings.AUTO_UPGRADE_ENERGY is True
                            and balance > energy_prices.get(next_energy_level +1, 0)
                            and next_energy_level <= settings.MAX_ENERGY_LEVEL
                        ):
                            await self.randomized_sleep()
                            status = await self.upgrade_boost(
                                http_client=http_client, boost_type="buffery"
                            )
                            if status is True:
                                logger.success(
                                    f"{self.session_name} | Energy upgraded to {next_energy_level} lvl"
                                )
                                await asyncio.sleep(delay=1)
                            continue

                        if (
                            settings.AUTO_UPGRADE_CHARGE is True
                            and balance > charge_prices.get(next_charge_level +1, 0)
                            and next_charge_level <= settings.MAX_CHARGE_LEVEL
                        ):
                            await self.randomized_sleep()
                            status = await self.upgrade_boost(
                                http_client=http_client, boost_type="recover"
                            )
                            if status is True:
                                logger.success(
                                    f"{self.session_name} | Recharging Speed upgraded to {next_charge_level} lvl"
                                )
                                await asyncio.sleep(delay=1)
                            continue

                        if available_energy < settings.MIN_AVAILABLE_ENERGY:
                            logger.info(
                                f"{self.session_name} | Minimum energy reached: {available_energy}"
                            )
                            logger.info(
                                f"{self.session_name} | Sleep {settings.SLEEP_BY_MIN_ENERGY}s"
                            )
                            await asyncio.sleep(delay=settings.SLEEP_BY_MIN_ENERGY)
                            continue

                except InvalidSession as error:
                    raise error

                except Exception as error:
                    logger.error(f"{self.session_name} | Unknown error: {error}")
                    await asyncio.sleep(delay=3)

                else:
                    sleep_between_clicks = randint(settings.SLEEP_BETWEEN_TAP[0], settings.SLEEP_BETWEEN_TAP[1])
                    
                    if active_turbo:
                        sleep_between_clicks = 20
                        logger.info(f"{sleep_between_clicks}s to Sleep between clicks")
                    
                    await asyncio.sleep(sleep_between_clicks)


async def run_tapper(tg_client: Client, proxy: str | None):
    try:
        await Tapper(tg_client=tg_client).run(proxy=proxy)
    except InvalidSession:
        logger.error(f"{tg_client.name} | Invalid Session")
