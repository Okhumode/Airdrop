# Consult your village people if you still mess this up

import os
os.system('python -m pip install -r requirements.txt')