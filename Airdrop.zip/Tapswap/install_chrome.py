import subprocess
import os
import sys

def run_command(command, shell=False):
    """Run a shell command."""
    try:
        result = subprocess.run(command, shell=shell, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        print(result.stdout.decode())
    except subprocess.CalledProcessError as e:
        print(f"Error running command {command}: {e.stderr.decode()}", file=sys.stderr)
        sys.exit(1)

def main():
    if os.geteuid() != 0:
        print("This script must be run as root.", file=sys.stderr)
        sys.exit(1)

    print("Installing necessary packages...")
    run_command(['apt', 'install', '-y', 'software-properties-common', 'apt-transport-https', 'ca-certificates', 'curl'])

    print("Setting up the Chrome repository without GPG check...")
    repo_content = 'deb [arch=amd64 trusted=yes] http://dl.google.com/linux/chrome/deb/ stable main'
    with open('/etc/apt/sources.list.d/google-chrome.list', 'w') as f:
        f.write(repo_content)

    print("Updating package lists...")
    run_command(['apt', 'update'])

    print("Installing Google Chrome...")
    run_command(['apt', 'install', '-y', 'google-chrome-stable'])

    print("Google Chrome installation completed.")

if __name__ == "__main__":
    main()

