import glob
import os
import pathlib
import shutil
import time
from typing import Union
from multiprocessing import Queue
from selenium import webdriver
from pyrogram import Client
from pyrogram.types import Message
from bot.utils import logger
import asyncio
from bot.utils.emojis import num, StaticEmoji
import json

def get_session_names() -> list[str]:
    session_names = glob.glob("sessions/*.session")
    session_names = [os.path.splitext(os.path.basename(file))[0] for file in session_names]
    return session_names

from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options as ChromeOptions
from webdriver_manager.chrome import ChromeDriverManager
web_options = ChromeOptions
web_service = ChromeService
web_manager = ChromeDriverManager
web_driver = webdriver.Chrome

# Ensure the webdriver directory exists and contains the appropriate driver
if not pathlib.Path("webdriver").exists() or len(list(pathlib.Path("webdriver").iterdir())) == 0:
    logger.info("Downloading webdriver. It may take some time...")
    pathlib.Path("webdriver").mkdir(parents=True, exist_ok=True)
    webdriver_path = pathlib.Path(web_manager().install())
    shutil.move(webdriver_path, f"webdriver/{webdriver_path.name}")
    logger.info("Webdriver downloaded successfully")

webdriver_path = next(pathlib.Path("webdriver").iterdir()).as_posix()

mobile_emulation = {
    "deviceMetrics": {
        "width": 360,
        "height": 640,
        "pixelRatio": 3.0,
        "touch": True,
    },
    "userAgent": "Mozilla/5.0 (Linux; Android 12; SM-G7810 Build/V417IR; wv) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36",
    "clientHints": {
        "platform": "Android",
        "mobile": True
    }
}

options = web_options()
options.add_argument("--headless")
options.add_argument("--disable-extensions")
options.add_argument("--no-sandbox")
options.add_experimental_option("mobileEmulation", mobile_emulation)
options.set_capability(
    "goog:loggingPrefs", {"performance": "ALL"}
)

service = web_service(executable_path=webdriver_path)

# Queue to manage sessions
session_queue = Queue()

def get_command_args(message: Union[Message, str], command: Union[str, list[str]] = None, prefixes: str = "/") -> str:
    if isinstance(message, str):
        return message.split(f"{prefixes}{command}", maxsplit=1)[-1].strip()
    if isinstance(command, str):
        args = message.text.split(f"{prefixes}{command}", maxsplit=1)[-1].strip()
        return args
    elif isinstance(command, list):
        for cmd in command:
            args = message.text.split(f"{prefixes}{cmd}", maxsplit=1)[-1]
            if args != message.text:
                return args.strip()
    return ""

def with_args(text: str):
    def decorator(func):
        async def wrapped(client: Client, message: Message):
            if message.text and len(message.text.split()) == 1:
                await message.edit(f"<emoji id=5210952531676504517>❌</emoji>{text}")
            else:
                return await func(client, message)
        return wrapped
    return decorator

def get_help_text():
    return f"""<b>
{StaticEmoji.FLAG} [Demo version]

{num(1)} /help - Displays all available commands
{num(2)} /tap [on|start, off|stop] - Starts or stops the tapper

</b>"""

async def stop_tasks(client: Client = None) -> None:
    if client:
        all_tasks = asyncio.all_tasks(loop=client.loop)
    else:
        loop = asyncio.get_event_loop()
        all_tasks = asyncio.all_tasks(loop=loop)

    clicker_tasks = [task for task in all_tasks if isinstance(task, asyncio.Task) and task._coro.__name__ == 'run_tapper']
    for task in clicker_tasks:
        try:
            task.cancel()
        except:
            ...

def escape_html(text: str) -> str:
    return text.replace('<', '\\<').replace('>', '\\>')

def extract_chq(tg_web_data: str) -> int:
    options.add_argument("--log-level=3")
    driver = web_driver(service=service, options=options)
    driver.get(f"https://app.tapswap.club/?bot=app_bot_0#tgWebAppData={tg_web_data}&tgWebAppVersion=7.4&tgWebAppPlatform=android&tgWebAppThemeParams=%7B%22bg_color%22%3A%22%23ffffff%22%2C%22text_color%22%3A%22%23000000%22%2C%22hint_color%22%3A%22%23707579%22%2C%22link_color%22%3A%22%233390ec%22%2C%22button_color%22%3A%22%233390ec%22%2C%22button_text_color%22%3A%22%23ffffff%22%2C%22secondary_bg_color%22%3A%22%23f4f4f5%22%2C%22header_bg_color%22%3A%22%23ffffff%22%2C%22accent_text_color%22%3A%22%233390ec%22%2C%22section_bg_color%22%3A%22%23ffffff%22%2C%22section_header_text_color%22%3A%22%23707579%22%2C%22subtitle_text_color%22%3A%22%23707579%22%2C%22destructive_text_color%22%3A%22%23e53935%22%7D")
    time.sleep(5)
    
    logs_raw = driver.get_log("performance")
    logs = [json.loads(lr["message"])["message"] for lr in logs_raw]

    def log_filter(log_):
        return (
            log_["method"] == "Network.responseReceived"
            and "json" in log_["params"]["response"]["mimeType"]
        )

    for log in filter(log_filter, logs):
        request_id = log["params"]["requestId"]
        responses = driver.execute_cdp_cmd("Network.getResponseBody", {"requestId": request_id})
        
        json_body = json.loads(responses['body'])
        if 'access_token' in json.dumps(json_body):
            profile_data = json_body 

    cache_id = driver.execute_script(f"""
        try {{
            return window.ctx.api.account_login._context.headers.get('Cache-Id');
        }} catch (e) {{
            return e;
        }}
    """)

    access_token = driver.execute_script(f"""
        try {{
            return window.ctx._authToken;
        }} catch (e) {{
            return e;
        }}
    """)

    session_queue.put(1)

    if len(get_session_names()) == session_queue.qsize():
        logger.info("All sessions are closed. Quitting driver...")
        driver.quit()
        driver = None
        while session_queue.qsize() > 0:
            session_queue.get()
    
    return cache_id, access_token, profile_data
