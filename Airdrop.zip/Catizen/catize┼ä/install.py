import os
os.system('python -m pip install -r requirements.txt')