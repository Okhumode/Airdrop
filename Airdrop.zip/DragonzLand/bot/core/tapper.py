import asyncio
from time import time
from random import randint
from urllib.parse import unquote, quote
from typing import Optional
import aiohttp
from aiohttp_proxy import ProxyConnector
from better_proxy import Proxy
from pyrogram import Client
from pyrogram.errors import Unauthorized, UserDeactivated, AuthKeyUnregistered, FloodWait
from pyrogram.raw.functions.messages import RequestWebView

from bot.config import settings
from bot.utils import logger
from bot.exceptions import InvalidSession
from .headers import headers


class Tapper:
    def __init__(self, tg_client: Client):
        self.session_name = tg_client.name
        self.tg_client = tg_client
        self.run_tasks_claim = False 

    async def get_tg_web_data(self, proxy: Optional[str]) -> str:
        if proxy:
            proxy = Proxy.from_str(proxy)
            proxy_dict = dict(
                scheme=proxy.protocol,
                hostname=proxy.host,
                port=proxy.port,
                username=proxy.login,
                password=proxy.password,
            )
        else:
            proxy_dict = None

        self.tg_client.proxy = proxy_dict

        try:
            with_tg = True

            if not self.tg_client.is_connected:
                with_tg = False
                try:
                    await self.tg_client.connect()
                    
                except (Unauthorized, UserDeactivated, AuthKeyUnregistered):
                    raise InvalidSession(self.session_name)

            while True:
                try:
                    peer = await self.tg_client.resolve_peer("dragonz_land_bot")
                    break
                except FloodWait as fl:
                    fls = fl.value

                    logger.warning(f"{self.session_name} | FloodWait {fl}")
                    logger.info(f"{self.session_name} | Sleeping for {fls} seconds")

                    await asyncio.sleep(fls + 3)

            web_view = await self.tg_client.invoke(
                RequestWebView(
                    peer=peer,
                    bot=peer,
                    platform="android",
                    from_bot_menu=False,
                    url="https://bot.dragonz.land/",
                )
            )

            auth_url = web_view.url
            raw_tg_web_data = unquote(
                unquote(
                    auth_url.split("tgWebAppData=", maxsplit=1)[1].split(
                        "&tgWebAppVersion", maxsplit=1
                    )[0]
                )
            )
            tg_web_data = quote(raw_tg_web_data, safe="=&")
            me = await self.tg_client.get_me()
            self.user_id = me.id
            self.user_name = me.username

            if not with_tg:
                await self.tg_client.disconnect()
            return tg_web_data

        except InvalidSession as error:
            raise error

        except Exception as error:
            logger.error(
                f"{self.session_name} | Unknown error during Authorization: {error}"
            )
            await asyncio.sleep(delay=3)

    async def login(self, http_client: aiohttp.ClientSession):
        try:
            response = await http_client.get(url='https://bot.dragonz.land/api/me')
            response.raise_for_status()

            response_json = await response.json()
            profile_data = response_json

            return profile_data
        except Exception as error:
            logger.error(f"{self.session_name} | Unknown error while getting Profile Data: {error}")
            await asyncio.sleep(delay=3)


    async def level_up(self, http_client: aiohttp.ClientSession, boost_id: str) -> bool:
        try:
            response = await http_client.post(url='https://bot.dragonz.land/api/me/boosts/buy', json={"boostKey": boost_id})
            response.raise_for_status()

            response_json = await response.json()

            return response_json
        except Exception as error:
            logger.error(f"{self.session_name} | Unknown error when Apply {boost_id} Boost: {error}")
            await asyncio.sleep(delay=3)

            return False
        
    async def claim_reward(self, http_client: aiohttp.ClientSession, taskId: str) -> bool:
        try:
            response = await http_client.post(url='https://bot.dragonz.land/api/me/tasks/verify',
                                              json={"taskId": taskId})
            response.raise_for_status()
            if response is None or response == '':
               return {}
            else:
                 return response

        except Exception as error:
            if "400" in str(error):
               return False
            logger.error(f"{self.session_name} | Unknown error while Claiming Task {taskId} Reward {error}")
            await asyncio.sleep(delay=3)

            return False    

    # async def apply_turbo_boost(self, http_client: aiohttp.ClientSession):
    #     try:
    #         response = await http_client.post(url='https://api-backend.yescoin.gold/game/recoverSpecialBox')
    #         response.raise_for_status()

    #         response_json = await response.json()

    #         return response_json['data']
    #     except Exception as error:
    #         logger.error(f"{self.session_name} | Unknown error when Apply Turbo Boost: {error}")
    #         await asyncio.sleep(delay=3)

    #         return False

    # async def apply_energy_boost(self, http_client: aiohttp.ClientSession):
    #     try:
    #         response = await http_client.post(url='https://api-backend.yescoin.gold/game/recoverCoinPool')
    #         response.raise_for_status()

    #         response_json = await response.json()

    #         return response_json['data']
    #     except Exception as error:
    #         logger.error(f"{self.session_name} | Unknown error when Apply Energy Boost: {error}")
    #         await asyncio.sleep(delay=3)

    #         return False

    async def send_taps(self, http_client: aiohttp.ClientSession, taps: int) -> bool:
        try:
            response = await http_client.post(url='https://bot.dragonz.land/api/me/feed', json={"feedCount": taps})
            response.raise_for_status()

            if response is None or response == '':
               return {}
            else:
                 return response
            
        except Exception as error:
            logger.error(f"{self.session_name} | Unknown error while Tapping: {error}")
            await asyncio.sleep(delay=1)

    # async def send_taps_with_turbo(self, http_client: aiohttp.ClientSession) -> bool:
    #     try:
    #         special_box_info = await self.get_special_box_info(http_client=http_client)
    #         box_type = special_box_info['recoveryBox']['boxType']
    #         taps = special_box_info['recoveryBox']['specialBoxTotalCount']

    #         response = await http_client.post(url='https://api-backend.yescoin.gold/game/collectSpecialBoxCoin',
    #                                           json={'boxType': box_type, 'coinCount': taps})
    #         response.raise_for_status()

    #         response_json = await response.json()

    #         if not response_json['data']:
    #             return False

    #         status = response_json['data']['collectStatus']

    #         return status
    #     except Exception as error:
    #         logger.error(f"{self.session_name} | Unknown error when Tapping: {error}")
    #         await asyncio.sleep(delay=3)

    # async def check_proxy(self, http_client: aiohttp.ClientSession, proxy: Proxy) -> None:
    #     try:
    #         response = await http_client.get(url='https://httpbin.org/ip', timeout=aiohttp.ClientTimeout(5))
    #         ip = (await response.json()).get('origin')
    #         logger.info(f"{self.session_name} | Proxy IP: {ip}")
    #     except Exception as error:
    #         logger.error(f"{self.session_name} | Proxy: {proxy} | Error: {error}")

    async def run(self, proxy: str | None) -> None:
        access_token_created_time = 0
        active_turbo = False

        proxy_conn = ProxyConnector().from_url(proxy) if proxy else None

        async with aiohttp.ClientSession(headers=headers, connector=proxy_conn) as http_client:
            if proxy:
                await self.check_proxy(http_client=http_client, proxy=proxy)

            while True:
                try:
                    if  access_token_created_time <= 0:
                        tg_web_data = await self.get_tg_web_data(proxy=proxy)

                        http_client.headers["X-Init-Data"] = tg_web_data
                       
                        access_token_created_time = time()

                        profile_data = await self.login(http_client=http_client)

                        balance = profile_data['coins']
                        level = profile_data['level']
                        energy = profile_data['energy']

                        logger.info(f"{self.session_name} | Energy: <m>{energy}</m> | Level: <r>{level +1}</r> | "
                                    f"Balance: <y>{balance}</y>")
                        access_token_created_time = 1

                    taps = randint(a=settings.RANDOM_TAPS_COUNT[0], b=settings.RANDOM_TAPS_COUNT[1])
                    profile_data = await self.login(http_client=http_client)
                    available_energy = profile_data['energy']

                    tasks = profile_data["tasks"]
                    if tasks and not self.run_tasks_claim:
                        for task in tasks:
                            taskId = task["taskId"]
                            attempts = task["attempts"]
                            if attempts == 1:
                                # skip
                                continue

                            result = await self.claim_reward(http_client, taskId)
                            if result:
                                logger.info(f"Reward claimed successfully for task {taskId}.")
                            else:
                                logger.warning(f"Failed to claim reward for task {taskId}. Task is not yet Active👌")
                        self.run_tasks_claim = True   # cus i want it to run only once         

                    if active_turbo:
                        # taps += settings.ADD_TAPS_ON_TURBO
                        status = await self.send_taps_with_turbo(http_client=http_client)
                    else:
    
                        status = await self.send_taps(http_client=http_client, taps=taps)

                    balance = profile_data['coins']

                    logger.success(f"{self.session_name} | Successful tapped! | "
                                   f"Balance: <c>{balance}</c> (<g>+{taps}</g>) | Total: <e>{balance}</e>")

                    # boosts_info = await self.get_boosts_info(http_client=http_client)

                    # turbo_boost_count = boosts_info['specialBoxLeftRecoveryCount']
                    # energy_boost_count = boosts_info['coinPoolLeftRecoveryCount']

                    # next_tap_level = boosts_info['singleCoinLevel'] + 1
                    # next_energy_level = boosts_info['coinPoolTotalLevel'] + 1
                    # next_charge_level = boosts_info['coinPoolRecoveryLevel'] + 1

                    # next_tap_price = boosts_info['singleCoinUpgradeCost']
                    # next_energy_price = boosts_info['coinPoolTotalUpgradeCost']
                    # next_charge_price = boosts_info['coinPoolRecoveryUpgradeCost']

                    if active_turbo is False:
                        # if (energy_boost_count > 0
                        #         and available_energy < settings.MIN_AVAILABLE_ENERGY
                        #         and settings.APPLY_DAILY_ENERGY is True):
                        #     logger.info(f"{self.session_name} | Sleep 5s before activating the daily energy boost")
                        #     await asyncio.sleep(delay=5)

                        #     status = await self.apply_energy_boost(http_client=http_client)
                        #     if status is True:
                        #         logger.success(f"{self.session_name} | Energy boost applied")

                        #         await asyncio.sleep(delay=1)

                        #     continue

                        # if turbo_boost_count > 0 and settings.APPLY_DAILY_TURBO is True:
                        #     logger.info(f"{self.session_name} | Sleep 5s before activating the daily turbo boost")
                        #     await asyncio.sleep(delay=5)

                        #     status = await self.apply_turbo_boost(http_client=http_client)
                        #     if status is True:
                        #         logger.success(f"{self.session_name} | Turbo boost applied")

                        #         await asyncio.sleep(delay=1)

                        #         active_turbo = True
                        #         turbo_time = time()

                        #     continue

                        # if (settings.AUTO_UPGRADE_TAP is True
                        #         and balance > next_tap_price
                        #         and next_tap_level <= settings.MAX_TAP_LEVEL):
                        #     logger.info(f"{self.session_name} | Sleep 5s before upgrade tap to {next_tap_level} lvl")
                        #     await asyncio.sleep(delay=5)

                        #     status = await self.level_up(http_client=http_client, boost_id=1)
                        #     if status is True:
                        #         logger.success(f"{self.session_name} | Tap upgraded to {next_tap_level} lvl")

                        #         await asyncio.sleep(delay=1)

                        #     continue

                        # if (settings.AUTO_UPGRADE_ENERGY is True
                        #         and balance > next_energy_price
                        #         and next_energy_level <= settings.MAX_ENERGY_LEVEL):
                        #     logger.info(
                        #         f"{self.session_name} | Sleep 5s before upgrade energy to {next_energy_level} lvl")
                        #     await asyncio.sleep(delay=5)

                        #     status = await self.level_up(http_client=http_client, boost_id=3)
                        #     if status is True:
                        #         logger.success(f"{self.session_name} | Energy upgraded to {next_energy_level} lvl")

                        #         await asyncio.sleep(delay=1)

                        #     continue

                        # if (settings.AUTO_UPGRADE_CHARGE is True
                        #         and balance > next_charge_price
                        #         and next_charge_level <= settings.MAX_CHARGE_LEVEL):
                        #     logger.info(
                        #         f"{self.session_name} | Sleep 5s before upgrade charge to {next_charge_level} lvl")
                        #     await asyncio.sleep(delay=5)

                        #     status = await self.level_up(http_client=http_client, boost_id=2)
                        #     if status is True:
                        #         logger.success(f"{self.session_name} | Charge upgraded to {next_charge_level} lvl")

                        #         await asyncio.sleep(delay=1)

                        #     continue

                        if available_energy < settings.MIN_AVAILABLE_ENERGY:
                            logger.info(f"{self.session_name} | Minimum energy reached: {available_energy}")
                            logger.info(f"{self.session_name} | Sleep {settings.SLEEP_BY_MIN_ENERGY}s")

                            await asyncio.sleep(delay=settings.SLEEP_BY_MIN_ENERGY)

                            continue

                except InvalidSession as error:
                    raise error

                except Exception as error:
                    logger.error(f"{self.session_name} | Unknown error: {error}")
                    await asyncio.sleep(delay=3)

                else:
                    sleep_between_clicks_ms = randint(a=settings.SLEEP_BETWEEN_TAP[0], b=settings.SLEEP_BETWEEN_TAP[1])
                
                    if active_turbo:
                           active_turbo = False
                           sleep_between_clicks_ms = 0.5
                
                    logger.info(f"Sleep {sleep_between_clicks_ms}s") 
                    await asyncio.sleep(delay=sleep_between_clicks_ms)


async def run_tapper(tg_client: Client, proxy: str | None):
    try:
        await Tapper(tg_client=tg_client).run(proxy=proxy)
    except InvalidSession:
        logger.error(f"{tg_client.name} | Invalid Session")
