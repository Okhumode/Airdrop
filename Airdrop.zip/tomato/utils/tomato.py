from pyrogram.raw.functions.messages import RequestWebView
from urllib.parse import unquote
from utils.core import logger
from fake_useragent import UserAgent
from pyrogram import Client
from data import config
from time import time
import aiohttp
import asyncio
import random
import json
from datetime import datetime


class Tomato:
    def __init__(self, thread: int, account: str, proxy : str):
        self.thread = thread
        self.name = account
        if proxy:
            proxy_client = {
                "scheme": config.PROXY_TYPE,
                "hostname": proxy.split(':')[0],
                "port": int(proxy.split(':')[1]),
                "username": proxy.split(':')[2],
                "password": proxy.split(':')[3],
            }
            self.client = Client(name=account, api_id=config.API_ID, api_hash=config.API_HASH, workdir=config.WORKDIR, proxy=proxy_client)
        else:
            self.client = Client(name=account, api_id=config.API_ID, api_hash=config.API_HASH, workdir=config.WORKDIR)

        if proxy:
            self.proxy = f"{config.PROXY_TYPE}://{proxy.split(':')[2]}:{proxy.split(':')[3]}@{proxy.split(':')[0]}:{proxy.split(':')[1]}"
        else:
            self.proxy = None

        self.ref_token=""
        headers = {'User-Agent': UserAgent(os='android').random}
        self.session = aiohttp.ClientSession(headers=headers, trust_env=True, connector=aiohttp.TCPConnector(verify_ssl=False))
        self.task_call_timer = time()
        self.task_call_counter = 0 

    async def main(self):
        await asyncio.sleep(random.randint(*config.ACC_DELAY))
        access_token = await self.login()
        if not access_token:
            await self.session.close()
            return 0
        logger.info(f"main | Thread {self.thread} | {self.name} | Start! | PROXY : {self.proxy}")
        while True:
            try:
                self.session.headers['Authorization'] = access_token

                already_claimed = await self.claim_daily_reward()
                if not already_claimed:
                    logger.info("Daily reward claimed")
                await asyncio.sleep(random.randint(*config.MINI_SLEEP))

                try:
                    timestamp, start_time, end_time, user_balance = await self.balance()
                except:
                    continue

               
                if self.task_call_counter < 1 or time() - self.task_call_timer >= 120:    
                    await self.do_tasks()
                    self.task_call_timer = time()
                    self.task_call_counter += 1

                await asyncio.sleep(random.randint(*config.MINI_SLEEP))

                if config.SPEND_TICKETS:
                    tickets_balance = await self.get_tickets_balance()
                    logger.info(f"main | Thread {self.thread} | {self.name} |You Have {tickets_balance} Tickets! | {user_balance} coins ")
                    for _ in range(tickets_balance):
                        await self.game()
                        await asyncio.sleep(random.randint(*config.SLEEP_GAME_TIME))

                if start_time is not None and end_time is not None and timestamp >= end_time:

                    claimed_amount = await self.claim()
                    logger.success(f"main | Thread {self.thread} | {self.name} | Claimed Farming reward! Balance: {claimed_amount}")

                    await asyncio.sleep(random.randint(*config.MINI_SLEEP))

                    await self.start()
                    logger.info(f"main | Thread {self.thread} | {self.name} | Farming Started!")

                else:
                    add_sleep = random.randint(8, 10)  # added some extra seconds.
                    time_difference = end_time - timestamp + add_sleep
                    hours = time_difference // 3600
                    minutes = (time_difference % 3600) // 60
                    seconds = time_difference % 60
                    logger.info(f"main | Thread {self.thread} | {self.name} | Sleep {hours} hours, {minutes} minutes, {seconds} seconds !")
                    await asyncio.sleep(time_difference)
                    await self.login()
                await asyncio.sleep(random.randint(*config.MINI_SLEEP))
            except Exception as err:
                logger.error(f"main | Thread {self.thread} | {self.name} | {err}")
                await asyncio.sleep(5 * random.randint(*config.MINI_SLEEP))

    async def claim(self):
        try:
            payload = {"game_id":"53b22103-c7ff-413d-bc63-20f6fb806a07"}
            resp = await self.session.post("https://api-web.tomarket.ai/tomarket-game/v1/farm/claim",json = payload, proxy = self.proxy)
            resp_json = await resp.json()
            return resp_json.get('data', {}).get('claim_this_time')
        except:
            pass

    async def start(self):
        try:
            payload = {"game_id":"53b22103-c7ff-413d-bc63-20f6fb806a07"}
            resp = await self.session.post("https://api-web.tomarket.ai/tomarket-game/v1/farm/start",json = payload, proxy = self.proxy)
        except:
            pass

    async def balance(self):
        try:    
            resp = await self.session.post("https://api-web.tomarket.ai/tomarket-game/v1/user/balance", proxy=self.proxy)
            resp_json = await resp.json()
            timestamp = resp_json.get('data', {}).get('timestamp')
            user_balance = resp_json.get('data', {}).get('available_balance')

            # Start farming
            payload = {"game_id": "53b22103-c7ff-413d-bc63-20f6fb806a07"}
            farm = await self.session.post("https://api-web.tomarket.ai/tomarket-game/v1/farm/start", json=payload, proxy=self.proxy)
            farm_json = await farm.json()

            start_time = None
            end_time = None
            if farm_json.get("data"):
                start_time = farm_json["data"].get("start_at")
                end_time = farm_json["data"].get("end_at")
                start_time = start_time if start_time else None
                end_time = end_time if end_time else None

            return timestamp, start_time, end_time, user_balance
        except Exception as e:
            logger.error(f"An error occurred: {e}")
            return None, None, None, None

    async def login(self):
        try:
            tg_web_data = await self.get_tg_web_data()
            if tg_web_data == False:
                return False
            json_data = {"init_data": await self.get_tg_web_data(), "invite_code":""}
            resp = await self.session.post("https://api-web.tomarket.ai/tomarket-game/v1/user/login", json=json_data,proxy = self.proxy)
            resp = await resp.json()
            self.ref_token = resp.get("data").get("access_token")
            access_token = self.ref_token
            self.session.headers['Authorization'] = (resp).get("data").get("access_token")
            return access_token
        except Exception as err:
            logger.error(f"login | Thread {self.thread} | {self.name} | {err}")
            if err == "Server disconnected":
                return True
            return False

    async def get_tg_web_data(self):
        await self.client.connect()
        try:
            web_view = await self.client.invoke(RequestWebView(
                peer=await self.client.resolve_peer('Tomarket_ai_bot'),
                bot=await self.client.resolve_peer('Tomarket_ai_bot'),
                platform='android',
                from_bot_menu=False,
                url='https://mini-app.tomarket.ai/'
            ))

            auth_url = web_view.url
        except Exception as err:
            logger.error(f"main | Thread {self.thread} | {self.name} | {err}")
            if 'USER_DEACTIVATED_BAN' in str(err):
                logger.error(f"login | Thread {self.thread} | {self.name} | USER BANNED")
                await self.client.disconnect()
                return False
        await self.client.disconnect()
        return unquote(string=unquote(string=auth_url.split('tgWebAppData=')[1].split('&tgWebAppVersion')[0]))

    async def do_tasks(self):
        try:
            resp = await self.session.post("https://api-web.tomarket.ai/tomarket-game/v1/tasks/list", proxy=self.proxy)
            resp_json = await resp.json()
            tasks = resp_json.get("data", {})
       
            for _, task_list in tasks.items():
                if not isinstance(task_list, list):
                    continue
                
                for task in task_list:
                    task_id = task.get('taskId')
                    title = task.get('title')
                    score = task.get('score')
                    status = task.get('status')
                    wait_seconds = task.get('waitSecond', 0)
                    end_time = task.get('endTime', '')

                    if end_time:
                        try:
                            end_time_obj = datetime.strptime(end_time, "%Y-%m-%d %H:%M:%S")
                        except ValueError as e: # if the werey is not pasrsed, set a past date and time
                            logger.error(f"Error parsing end time: {e}")
                            end_time = "2024-08-01 14:00:00"
                            end_time_obj = datetime.strptime(end_time, "%Y-%m-%d %H:%M:%S")
                    else: # if the werey is none, set a past date and time
                        end_time = "2024-08-01 14:00:00"
                        end_time_obj = datetime.strptime(end_time, "%Y-%m-%d %H:%M:%S")

                    now = datetime.now()
                    formatted_date_time = now.strftime("%Y-%m-%d %H:%M:%S")
                    formatted_date_time_obj = datetime.strptime(formatted_date_time, "%Y-%m-%d %H:%M:%S")

                    logger.info(f"Found task: {title} | Score: {score} | Status: {status} | Wait seconds: {wait_seconds}")
       
                    if status == 3:
                        logger.info(f"Skipping task {title} as it is already completed.")
                        continue
       
                    payload = {"task_id": task_id}
       
                    if status == 0 and task_id !=53 and "Mysterious task" not in title:
                        start_resp = await self.session.post("https://api-web.tomarket.ai/tomarket-game/v1/tasks/start", json=payload, proxy=self.proxy)
                        start_resp_json = await start_resp.json()
                        await asyncio.sleep(5)
       
                        if start_resp_json.get('data', {}).get('status') == 1:
                            logger.info(f"Started task: {title}")
                            await asyncio.sleep(wait_seconds)
                            logger.info(f"Waiting for {wait_seconds}s for task checking to complete")
                            check_resp = await self.session.post("https://api-web.tomarket.ai/tomarket-game/v1/tasks/check", json=payload, proxy=self.proxy)
       
                            try:
                                check_resp_json = await check_resp.json()
                            except json.JSONDecodeError as e:
                                logger.error(f"Failed to decode JSON response: {e}")
                                continue
       
                            if isinstance(check_resp_json, str):
                                logger.error(f"Received string response instead of JSON: {check_resp_json}")
                                continue
       
                            if check_resp_json.get('data', {}).get('status') == 2:
                                logger.info(f"Task checking completed: {title}")
                                await asyncio.sleep(2)
                                claim_resp = await self.session.post("https://api-web.tomarket.ai/tomarket-game/v1/tasks/claim", json=payload, proxy=self.proxy)
       
                                try:
                                    claim_resp_json = await claim_resp.json()
                                except json.JSONDecodeError as e:
                                    logger.error(f"Failed to decode JSON response: {e}")
                                    continue
       
                                if isinstance(claim_resp_json, str):
                                    logger.error(f"Received string response instead of JSON: {claim_resp_json}")
                                    continue
       
                                if claim_resp_json.get('data', {}) == "ok":
                                    logger.info(f"Claimed task reward: {title}")
                                else:
                                    logger.warning(f"Failed to claim task reward: {title}")
                            else:
                                logger.warning(f"Failed to check task: {title}")
                        else:
                            logger.warning(f"Failed to start task: {title}")
       
                    elif status == 2:
                        logger.info(f"Task {title} is ready for claim. Proceeding to check and claim.")
                        check_resp = await self.session.post("https://api-web.tomarket.ai/tomarket-game/v1/tasks/check", json=payload, proxy=self.proxy)
       
                        try:
                            check_resp_json = await check_resp.json()
                        except json.JSONDecodeError as e:
                            logger.error(f"Failed to decode JSON response: {e}")
                            continue
       
                        if isinstance(check_resp_json, str):
                            logger.error(f"Received string response instead of JSON: {check_resp_json}")
                            continue
       
                        if check_resp_json.get('data', {}).get('status') == 2:
                            logger.info(f"Task checking completed: {title}")
                            await asyncio.sleep(2)
                            claim_resp = await self.session.post("https://api-web.tomarket.ai/tomarket-game/v1/tasks/claim", json=payload, proxy=self.proxy)
       
                            try:
                                claim_resp_json = await claim_resp.json()
                            except json.JSONDecodeError as e:
                                logger.error(f"Failed to decode JSON response: {e}")
                                continue
       
                            if isinstance(claim_resp_json, str):
                                logger.error(f"Received string response instead of JSON: {claim_resp_json}")
                                continue
       
                            if claim_resp_json.get('data', {}) == "ok":
                                logger.info(f"Claimed task reward: {title}")
                            else:
                                logger.warning(f"Failed to claim task reward: {title}")
                        else:
                            logger.warning(f"Failed to check task: {title}")
                         
                    elif status == 0 and "Mysterious task" in title and formatted_date_time_obj < end_time_obj:
                        logger.info(f"Claiming the Daily Combos: {title} with ID: {task_id}")
                        await asyncio.sleep(2)
                        claim_resp = await self.session.post("https://api-web.tomarket.ai/tomarket-game/v1/tasks/claim", json=payload, proxy=self.proxy)
       
                        try:
                            claim_resp_json = await claim_resp.json()
                        except json.JSONDecodeError as e:
                            logger.error(f"Failed to decode JSON response: {e}")
                            continue
       
                        if isinstance(claim_resp_json, str):
                            logger.error(f"Received string response instead of JSON: {claim_resp_json}")
                            continue
       
                        if claim_resp_json.get('data', {}) == "ok":
                            logger.info(f"Claimed task reward: {title}")
                        else:
                            logger.warning(f"Failed to claim task reward: {title} with ID: {task_id}")
       
                    await asyncio.sleep(random.randint(1, 3))
       
        except Exception as err:
            logger.error(f"Error in do_tasks: {err}")


    async def get_tickets_balance(self):
        resp = await self.session.post("https://api-web.tomarket.ai/tomarket-game/v1/user/balance",proxy = self.proxy)
        resp_json = await resp.json()
        return resp_json['data']['play_passes']

    async def game(self):
        gameId = "59bcd12e-04e2-404c-a172-311a0084587d"
        payload = {"game_id":gameId}
        response = await self.session.post('https://api-web.tomarket.ai/tomarket-game/v1/game/play', json = payload, proxy=self.proxy)
        response_json = await response.json()
        logger.info(f"game | Thread {self.thread} | {self.name} | Start TOMATO GAME!")

        if not response_json.get('data', {}).get('end_at'):
            logger.error(f"game | Thread {self.thread} | {self.name} | TOMATO GAME CAN'T START")
            return
        count = random.randint(*config.POINTS)
        await asyncio.sleep(31)

        json_data = {
            'game_id': gameId,
            'points': count,
        }
        response = await self.session.post('https://api-web.tomarket.ai//tomarket-game/v1/game/claim', json=json_data, proxy=self.proxy)
        response_json = await response.json()
        if "data" in response_json and "points" in response_json["data"]:
            points = response_json["data"]["points"]
            logger.success(f"game | Thread {self.thread} | {self.name} | Claimed TOMATO GAME ! Claimed: {points}")
        else:
            logger.error(f"game | Thread {self.thread} | {self.name} | {await response.text()}")

    async def claim_daily_reward(self):
        try:
            payload = {"game_id": "fa873d13-d831-4d6f-8aee-9cff7a1d0db1"}
            resp = await self.session.post("https://api-web.tomarket.ai/tomarket-game/v1/daily/claim", json=payload, proxy=self.proxy)
            txt = await resp.text()

            if 'already_check' in txt:
                return True 
            else:
                return False 
        except Exception as e:
            logger.error(f"An error occurred: {e}")
            return False
